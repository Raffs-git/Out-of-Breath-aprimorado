export default class Star {
    constructor(x, y, radius, velocity) {
        this.position = { x, y };
        this.radius = radius;
        this.velocity = velocity;
        this.opacity = Math.random() * 0.5 + 0.5; // Brilho aleatório
        this.twinklSpeed = Math.random() * 0.02 + 0.01;
    }

    draw(ctx) {
        ctx.save();
        ctx.fillStyle = `rgba(255, 255, 255, ${this.opacity})`;
        ctx.beginPath();
        ctx.arc(this.position.x, this.position.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();
        ctx.restore();
    }

    update() {
        this.position.y += this.velocity;
        // Efeito de cintilação
        this.opacity += this.twinklSpeed;
        if (this.opacity >= 1 || this.opacity <= 0.3) {
            this.twinklSpeed *= -1;
        }
    }

    isOffScreen(canvasHeight) {
        return this.position.y > canvasHeight;
    }
}