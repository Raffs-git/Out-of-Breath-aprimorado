
import { PATH_ASTEROID_IMAGE } from "../utils/constants.js";

export default class Asteroid {
    constructor(x, y, radius, velocity) {
        this.position = { x, y };
        this.radius = radius;
        this.velocity = velocity;

        this.image = new Image();
        this.image.src = PATH_ASTEROID_IMAGE;
        this.imageLoaded = false;
        this.image.onload = () => { this.imageLoaded = true; };
    }

    draw(ctx) {
        // Draw image with wider width and shorter height to appear "gordinho"
        const drawWidth = this.radius * 6; // wider
        const drawHeight = this.radius * 6; // less tall
        if (this.imageLoaded) {
            ctx.drawImage(
                this.image,
                this.position.x - drawWidth / 2,
                this.position.y - drawHeight / 2,
                drawWidth,
                drawHeight
            );
        } else {
            ctx.beginPath();
            ctx.arc(this.position.x, this.position.y, this.radius, 0, Math.PI * 2, false);
            ctx.fillStyle = 'blue';
            ctx.fill();
            ctx.closePath();
        }
    }

    update() {
        this.position.y += this.velocity.y;
    }

    hit(projectile) {
        const projX = projectile.position.x + (projectile.width ? projectile.width / 2 : 0);
        const projY = projectile.position.y + (projectile.height ? projectile.height / 2 : 0);
        const distance = Math.hypot(
            this.position.x - projX,
            this.position.y - projY
        );

        const projRadius = projectile.radius || Math.max(projectile.width, projectile.height) / 2 || 0;
        return distance - this.radius - projRadius < 1;
    }

    hitPlayer(player) {
        const distance = Math.hypot(
            this.position.x - (player.position.x + player.width / 2),
            this.position.y - (player.position.y + player.height / 2)
        );

        return distance - this.radius - (player.width / 2) < 1;
    }
}